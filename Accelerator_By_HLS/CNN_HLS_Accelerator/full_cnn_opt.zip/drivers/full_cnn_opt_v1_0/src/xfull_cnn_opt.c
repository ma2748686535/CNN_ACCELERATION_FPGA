// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xfull_cnn_opt.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFull_cnn_opt_CfgInitialize(XFull_cnn_opt *InstancePtr, XFull_cnn_opt_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFull_cnn_opt_Start(XFull_cnn_opt *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL) & 0x80;
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFull_cnn_opt_IsDone(XFull_cnn_opt *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFull_cnn_opt_IsIdle(XFull_cnn_opt *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFull_cnn_opt_IsReady(XFull_cnn_opt *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFull_cnn_opt_EnableAutoRestart(XFull_cnn_opt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL, 0x80);
}

void XFull_cnn_opt_DisableAutoRestart(XFull_cnn_opt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_AP_CTRL, 0);
}

void XFull_cnn_opt_Set_input_r(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_INPUT_R_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_input_r(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_INPUT_R_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_output_r(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_output_r(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_conv1_w(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_W_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_W_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_conv1_w(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_W_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_W_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_conv1_b(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_B_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_B_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_conv1_b(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_B_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV1_B_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_conv2_w(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_W_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_W_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_conv2_w(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_W_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_W_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_conv2_b(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_B_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_B_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_conv2_b(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_B_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_CONV2_B_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_fc_w(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_W_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_W_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_fc_w(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_W_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_W_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_Set_fc_b(XFull_cnn_opt *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_B_DATA, (u32)(Data));
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_B_DATA + 4, (u32)(Data >> 32));
}

u64 XFull_cnn_opt_Get_fc_b(XFull_cnn_opt *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_B_DATA);
    Data += (u64)XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_FC_B_DATA + 4) << 32;
    return Data;
}

void XFull_cnn_opt_InterruptGlobalEnable(XFull_cnn_opt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_GIE, 1);
}

void XFull_cnn_opt_InterruptGlobalDisable(XFull_cnn_opt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_GIE, 0);
}

void XFull_cnn_opt_InterruptEnable(XFull_cnn_opt *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_IER);
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_IER, Register | Mask);
}

void XFull_cnn_opt_InterruptDisable(XFull_cnn_opt *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_IER);
    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_IER, Register & (~Mask));
}

void XFull_cnn_opt_InterruptClear(XFull_cnn_opt *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFull_cnn_opt_WriteReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_ISR, Mask);
}

u32 XFull_cnn_opt_InterruptGetEnabled(XFull_cnn_opt *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_IER);
}

u32 XFull_cnn_opt_InterruptGetStatus(XFull_cnn_opt *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFull_cnn_opt_ReadReg(InstancePtr->Ctrl_BaseAddress, XFULL_CNN_OPT_CTRL_ADDR_ISR);
}

