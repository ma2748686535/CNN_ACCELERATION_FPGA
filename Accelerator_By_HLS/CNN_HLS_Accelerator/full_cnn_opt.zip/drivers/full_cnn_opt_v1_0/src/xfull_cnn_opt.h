// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XFULL_CNN_OPT_H
#define XFULL_CNN_OPT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfull_cnn_opt_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XFull_cnn_opt_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XFull_cnn_opt;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFull_cnn_opt_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFull_cnn_opt_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFull_cnn_opt_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFull_cnn_opt_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XFull_cnn_opt_Initialize(XFull_cnn_opt *InstancePtr, UINTPTR BaseAddress);
XFull_cnn_opt_Config* XFull_cnn_opt_LookupConfig(UINTPTR BaseAddress);
#else
int XFull_cnn_opt_Initialize(XFull_cnn_opt *InstancePtr, u16 DeviceId);
XFull_cnn_opt_Config* XFull_cnn_opt_LookupConfig(u16 DeviceId);
#endif
int XFull_cnn_opt_CfgInitialize(XFull_cnn_opt *InstancePtr, XFull_cnn_opt_Config *ConfigPtr);
#else
int XFull_cnn_opt_Initialize(XFull_cnn_opt *InstancePtr, const char* InstanceName);
int XFull_cnn_opt_Release(XFull_cnn_opt *InstancePtr);
#endif

void XFull_cnn_opt_Start(XFull_cnn_opt *InstancePtr);
u32 XFull_cnn_opt_IsDone(XFull_cnn_opt *InstancePtr);
u32 XFull_cnn_opt_IsIdle(XFull_cnn_opt *InstancePtr);
u32 XFull_cnn_opt_IsReady(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_EnableAutoRestart(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_DisableAutoRestart(XFull_cnn_opt *InstancePtr);

void XFull_cnn_opt_Set_input_r(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_input_r(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_output_r(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_output_r(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_conv1_w(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_conv1_w(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_conv1_b(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_conv1_b(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_conv2_w(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_conv2_w(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_conv2_b(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_conv2_b(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_fc_w(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_fc_w(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_Set_fc_b(XFull_cnn_opt *InstancePtr, u64 Data);
u64 XFull_cnn_opt_Get_fc_b(XFull_cnn_opt *InstancePtr);

void XFull_cnn_opt_InterruptGlobalEnable(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_InterruptGlobalDisable(XFull_cnn_opt *InstancePtr);
void XFull_cnn_opt_InterruptEnable(XFull_cnn_opt *InstancePtr, u32 Mask);
void XFull_cnn_opt_InterruptDisable(XFull_cnn_opt *InstancePtr, u32 Mask);
void XFull_cnn_opt_InterruptClear(XFull_cnn_opt *InstancePtr, u32 Mask);
u32 XFull_cnn_opt_InterruptGetEnabled(XFull_cnn_opt *InstancePtr);
u32 XFull_cnn_opt_InterruptGetStatus(XFull_cnn_opt *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
