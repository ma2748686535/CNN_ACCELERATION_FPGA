// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xfull_cnn_opt.h"

extern XFull_cnn_opt_Config XFull_cnn_opt_ConfigTable[];

#ifdef SDT
XFull_cnn_opt_Config *XFull_cnn_opt_LookupConfig(UINTPTR BaseAddress) {
	XFull_cnn_opt_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XFull_cnn_opt_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XFull_cnn_opt_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XFull_cnn_opt_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFull_cnn_opt_Initialize(XFull_cnn_opt *InstancePtr, UINTPTR BaseAddress) {
	XFull_cnn_opt_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFull_cnn_opt_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFull_cnn_opt_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XFull_cnn_opt_Config *XFull_cnn_opt_LookupConfig(u16 DeviceId) {
	XFull_cnn_opt_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFULL_CNN_OPT_NUM_INSTANCES; Index++) {
		if (XFull_cnn_opt_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFull_cnn_opt_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFull_cnn_opt_Initialize(XFull_cnn_opt *InstancePtr, u16 DeviceId) {
	XFull_cnn_opt_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFull_cnn_opt_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFull_cnn_opt_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

